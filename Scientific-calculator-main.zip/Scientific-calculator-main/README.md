# Scientific-calculator
It is a scientific calculator built with the help of Python and MySql used to perform the arithmetic and scientific calculation. 
